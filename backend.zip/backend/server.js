const express = require("express");
const cors = require("cors");
require("dotenv").config();
require("./config/db");
const authRoutes = require("./routes/authRoutes");
const patientRoutes = require("./routes/patientRoutes");


const app = express();

app.use(cors());
app.use(express.json());
app.use("/auth", authRoutes);
app.use("/patients", patientRoutes);

app.get("/patients/test", (req, res) => {
    res.send("Patients Route OK");
});
app.get("/", (req, res) => {
    res.send("Hospital Management API Running...");
});

app.post("/patients/add", (req, res) => {
    res.json({
        message: "Server Route Working"
    });
});



const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});
