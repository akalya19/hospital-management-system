const express = require("express");
const router = express.Router();

console.log("Patient Routes Loaded");

const patientController = require("../controllers/patientController");

router.post("/add", patientController.addPatient);

router.get("/", patientController.getPatients);

router.get("/:id", patientController.getPatientById);

router.put("/:id", patientController.updatePatient);

module.exports = router;