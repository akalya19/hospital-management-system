const db = require("../config/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password || !role) {
        return res.status(400).json({
            message: "All fields are required"
        });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const sql = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";

        db.query(sql, [name, email, hashedPassword, role], (err, result) => {

            if (err) {
                return res.status(500).json(err);
            }

            res.status(201).json({
                message: "User Registered Successfully"
            });

        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });

    }
};

exports.login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({
            message: "Email and Password are required"
        });
    }

    try {
        const sql = "SELECT * FROM users WHERE email = ?";
        db.query(sql, [email], async (err, results) => {
            if (err) {
                return res.status(500).json(err);
            }

            if (results.length === 0) {
                return res.status(404).json({
                    message: "User not found"
                });
            }

            const user = results[0];
            const isMatch = await bcrypt.compare(password, user.password);

            
            if (!isMatch) {
                return res.status(401).json({
                    message: "Invalid credentials"
                });
            }
            const token = jwt.sign(
                
                {
                     email: user.email,
                     role: user.role
                     },
                     process.env.JWT_SECRET,
                     {
                        expiresIn: "1d"
                    }
                );

   

            res.status(200).json({
                message: "Login Successful",
                email: user.email,
                role: user.role,
                token: token
            });
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};