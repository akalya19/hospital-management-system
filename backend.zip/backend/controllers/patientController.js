const db = require("../config/db");

// Add Patient
exports.addPatient = (req, res) => {
    const {
        patient_name,
        age,
        gender,
        phone,
        address,
        blood_group,
        disease
    } = req.body;

    const sql = `
        INSERT INTO patients
        (patient_name, age, gender, phone, address, blood_group, disease)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(
        sql,
        [patient_name, age, gender, phone, address, blood_group, disease],
        (err, result) => {
            if (err) {
                return res.status(500).json(err);
            }

            res.status(201).json({
                message: "Patient Added Successfully"
            });
        }
    );
};
// Get All Patients
exports.getPatients = (req, res) => {
    const sql = "SELECT * FROM patients";

    db.query(sql, (err, result) => {
        if (err) {
            return res.status(500).json(err);
        }

        res.status(200).json(result);
    });
};
// Get Patient By ID
exports.getPatientById = (req, res) => {
    const id = req.params.id;

    const sql = "SELECT * FROM patients WHERE id = ?";

    db.query(sql, [id], (err, result) => {
        if (err) {
            return res.status(500).json(err);
        }

        if (result.length === 0) {
            return res.status(404).json({
                message: "Patient Not Found"
            });
        }

        res.json(result[0]);
    });
};
// Update Patient
exports.updatePatient = (req, res) => {
    const id = req.params.id;

    const {
        patient_name,
        age,
        gender,
        phone,
        address,
        blood_group,
        disease
    } = req.body;

    const sql = `
        UPDATE patients
        SET patient_name = ?, age = ?, gender = ?, phone = ?, address = ?, blood_group = ?, disease = ?
        WHERE id = ?
    `;

    db.query(
        sql,
        [patient_name, age, gender, phone, address, blood_group, disease, id],
        (err, result) => {
            if (err) {
                return res.status(500).json(err);
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    message: "Patient Not Found"
                });
            }

            res.json({
                message: "Patient Updated Successfully"
            });
        }
    );
};